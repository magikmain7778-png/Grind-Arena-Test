# Grind Arena (nome provisório) — FPS 3D de arena para Android

Protótipo em **Godot 4 + GDScript**. Estado real: veja `PROJECT_STATUS.md`.
**Aviso:** o código da Fase 1 foi escrito mas **ainda não foi executado no Godot** (ver `TESTS.md`).

## Como abrir (iniciante, no PC)
1. Baixe o Godot 4.6.x (versão estável, "Standard", NÃO a ".NET") em https://godotengine.org/download
2. Descompacte e abra o Godot. Clique em **Importar** e escolha o arquivo `project.godot` desta pasta.
3. Aperte **F5** (Executar). Controles no PC: W/A/S/D andam, Espaço pula,
   arrastar o mouse na **metade direita** da tela mira, e o botão de pulo aparece embaixo à direita.
   (O mouse simula toque.)
4. Se aparecer erro vermelho, copie o texto e me envie.

## Teste automático (opcional)
`godot --headless --path . --script res://tests/smoke_test.gd`  → deve imprimir `PASS: OK`.
Verificação sem Godot: `python3 tools/static_check.py`.

## Gerar APK
Ainda não feito. Requisitos (confirmados na documentação): JDK 17, Android SDK (platform-tools,
build-tools, platform android-35), modelos de exportação da MESMA versão do Godot, keystore de debug.
Passo a passo detalhado será escrito em `docs/ANDROID_EXPORT.md` na Fase 1 final.
