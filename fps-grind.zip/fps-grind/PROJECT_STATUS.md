# Status do projeto
**Fase atual:** 0 concluída (auditoria); 1 em andamento (código escrito, NÃO executado).

| Item | Estado |
|---|---|
| Projeto criado | SIM |
| Protótipo executável | NÃO VERIFICADO (Godot indisponível neste ambiente) |
| APK compilado | NÃO |
| APK instalado/testado no Android | NÃO |
| Partida offline | NÃO |
| Multiplayer | NÃO |
| Ultimates globais / combinadas | NÃO |
| Sistema musical | NÃO |

Implementado (não validado): arena com colisões, jogador 1ª pessoa, joystick + mira por toque + pulo,
alvo estático, contador de FPS.
Tamanho atual do projeto: ~poucos KB (sem assets). Orçamento: 8 GB (limite, não meta).
