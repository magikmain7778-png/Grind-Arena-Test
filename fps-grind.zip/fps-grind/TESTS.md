# Testes
| Teste | Como rodar | Resultado |
|---|---|---|
| Verificação estática (arquivos referenciados, indentação, parênteses) | `python3 tools/static_check.py` | **PASSOU** (executado nesta sessão). Só valida estrutura superficial. |
| Smoke test (cena carrega, jogador no chão, anda ao receber joystick) | `godot --headless --path . --script res://tests/smoke_test.gd` | **NÃO EXECUTADO** (sem Godot) |
| Controles de toque reais (joystick e mira simultâneos, sem bloquear) | Manual no celular | **PENDENTE – depende de você** |
| Colisão/pulo/rampa no jogo | Manual: F5 no PC | **PENDENTE – depende de você** |
| FPS no aparelho | Ler contador na tela no celular | **PENDENTE** (nenhum valor inventado) |
