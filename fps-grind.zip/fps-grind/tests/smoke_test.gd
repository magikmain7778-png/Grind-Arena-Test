extends SceneTree
# Teste de fumaca sem interface. Rodar (quando o Godot estiver instalado):
#   godot --headless --path . --script res://tests/smoke_test.gd
# Passa se: a cena carrega, o jogador cai e fica NO CHAO (colisao) e anda ao receber entrada.

var _frames := 0
var _main: Node
var _start_z := 0.0


func _initialize() -> void:
    _main = load("res://scenes/main.tscn").instantiate()
    root.add_child(_main)


func _process(_delta: float) -> bool:
    _frames += 1
    var p: CharacterBody3D = _main.get_node_or_null("Player")
    if p == null:
        return _finish(false, "Player nao encontrado")
    if _frames == 90:
        if not p.is_on_floor():
            return _finish(false, "Player nao esta no chao apos 90 frames")
        if p.global_position.y < -0.5:
            return _finish(false, "Player atravessou o chao")
        _start_z = p.global_position.z
        _main.get_node("TouchControls").move_vector = Vector2(0, -1)  # frente
    if _frames == 150:
        if p.global_position.z >= _start_z - 1.0:
            return _finish(false, "Player nao andou para frente")
        return _finish(true, "OK")
    return false


func _finish(ok: bool, msg: String) -> bool:
    print(("PASS: " if ok else "FAIL: ") + msg)
    quit(0 if ok else 1)
    return true
