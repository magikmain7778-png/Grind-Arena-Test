#!/usr/bin/env python3
"""Verificacoes estaticas que NAO precisam do Godot. Nao substitui rodar o jogo."""
import re, sys, pathlib

root = pathlib.Path(__file__).resolve().parent.parent
errors = []

proj = (root / "project.godot").read_text()
for key in ["config_version=5", "run/main_scene=", "GL Compatibility"]:
    if key not in proj:
        errors.append(f"project.godot sem: {key}")

for f in list(root.rglob("*.gd")) + list(root.rglob("*.tscn")) + [root / "project.godot"]:
    for m in re.finditer(r'res://([A-Za-z0-9_/\.\-]+)', f.read_text()):
        if not (root / m.group(1)).exists():
            errors.append(f"{f.relative_to(root)}: aponta para arquivo inexistente res://{m.group(1)}")

for f in root.rglob("*.gd"):
    text = f.read_text()
    has_tab = has_space = False
    for i, line in enumerate(text.splitlines(), 1):
        lead = line[:len(line) - len(line.lstrip())]
        if "\t" in lead and " " in lead:
            errors.append(f"{f.relative_to(root)}:{i}: tab e espaco misturados")
        has_tab |= "\t" in lead
        has_space |= " " in lead
    if has_tab and has_space:
        errors.append(f"{f.relative_to(root)}: arquivo mistura indentacao por tab e espaco")
    stripped = re.sub(r'"[^"\n]*"', '""', text)
    stripped = re.sub(r'#.*', '', stripped)
    for a, b in ["()", "[]", "{}"]:
        if stripped.count(a) != stripped.count(b):
            errors.append(f"{f.relative_to(root)}: {a}{b} desbalanceado")

if errors:
    print("FALHOU:")
    for e in errors: print(" -", e)
    sys.exit(1)
print("static_check: OK (so estrutura/sintaxe superficial; Godot ainda nao executou nada)")
