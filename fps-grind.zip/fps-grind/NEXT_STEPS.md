# Próxima tarefa concreta
1. (Você) Abrir o projeto no Godot 4.6.x e apertar F5; me enviar erros ou "funcionou".
2. (Eu) Corrigir o que falhar; criar `docs/ANDROID_EXPORT.md` e `export_presets.cfg`.
3. (Eu) Preparar workflow gratuito de build do APK na nuvem (GitHub Actions) se você não tiver PC.
4. Só então: Fase 2 (tiro, vida, dano, eliminação, placar).
