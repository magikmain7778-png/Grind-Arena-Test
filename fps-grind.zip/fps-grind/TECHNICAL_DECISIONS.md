# Decisões técnicas
## Ambiente de desenvolvimento (medido na Fase 0)
Ubuntu 24.04 x86_64, 1 CPU, 3,9 GB RAM, Git 2.43, OpenJDK 21 (só JRE+keytool, sem javac), Python 3.12.
SEM: Godot, Android SDK, adb, gradle, internet no terminal (github.com não resolve).
Consequência: não dá para executar o Godot nem exportar APK aqui.

## Versões
- Godot alvo: **4.6.x estável** (4.6.3 aparece listada em mirror de terceiros com data de 20/05/2026;
  4.7.x já existe mas é mais nova). Confirmar a versão exata em godotengine.org antes de baixar.
  Modelos de exportação PRECISAM ser da mesma versão do editor.
- JDK: 17 recomendado pela documentação (versões maiores "também podem funcionar").
- Android SDK: platform-tools, build-tools 35.0.1, platforms;android-35 (conforme doc do Godot; confirmar).
## Escolhas
- Renderizador **GL Compatibility**: máxima compatibilidade com celulares modestos.
- Tudo construído por código (sem .tscn complexos): reduz erro de edição manual sem editor.
- Sem `class_name` nos scripts: evita depender do cache de classes na 1ª abertura/exportação.
- Orientação: paisagem por sensor (`handheld/orientation=4`).
- Mouse simula toque (`emulate_touch_from_mouse`) para testar controles no PC.
- Sombras desligadas por padrão (desempenho).
