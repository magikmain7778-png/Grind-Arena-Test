extends CanvasLayer
# Controles de toque: joystick (metade esquerda), mira por arrasto (metade direita)
# e botao de pulo. Usa o indice de cada dedo, entao movimento e mira funcionam juntos.

const JOY_RADIUS := 120.0
const BTN_SIZE := 140.0

var move_vector := Vector2.ZERO   # x: direita(+), y: tras(+)  (cima na tela = frente)
var look_delta := Vector2.ZERO    # acumulado ate ser consumido
var jump_held := false

var _move_touch := -1
var _look_touch := -1
var _jump_touch := -1
var _move_origin := Vector2.ZERO
var _overlay: Control


func _ready() -> void:
    layer = 10
    _overlay = Control.new()
    _overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
    _overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _overlay.draw.connect(_on_overlay_draw)
    add_child(_overlay)


func consume_look() -> Vector2:
    var d := look_delta
    look_delta = Vector2.ZERO
    return d


func _jump_rect() -> Rect2:
    var vp := get_viewport().get_visible_rect().size
    return Rect2(vp.x - BTN_SIZE - 40.0, vp.y - BTN_SIZE - 40.0, BTN_SIZE, BTN_SIZE)


func _input(event: InputEvent) -> void:
    var vp := get_viewport().get_visible_rect().size
    if event is InputEventScreenTouch:
        if event.pressed:
            if _jump_touch == -1 and _jump_rect().has_point(event.position):
                _jump_touch = event.index
                jump_held = true
            elif _move_touch == -1 and event.position.x < vp.x * 0.5:
                _move_touch = event.index
                _move_origin = event.position
                move_vector = Vector2.ZERO
            elif _look_touch == -1 and event.position.x >= vp.x * 0.5:
                _look_touch = event.index
        else:
            if event.index == _jump_touch:
                _jump_touch = -1
                jump_held = false
            elif event.index == _move_touch:
                _move_touch = -1
                move_vector = Vector2.ZERO
            elif event.index == _look_touch:
                _look_touch = -1
        _overlay.queue_redraw()
    elif event is InputEventScreenDrag:
        if event.index == _move_touch:
            move_vector = ((event.position - _move_origin) / JOY_RADIUS).limit_length(1.0)
            _overlay.queue_redraw()
        elif event.index == _look_touch:
            look_delta += event.relative


func _on_overlay_draw() -> void:
    var vp := get_viewport().get_visible_rect().size
    var base := Vector2(180.0, vp.y - 180.0)
    if _move_touch != -1:
        base = _move_origin
    _overlay.draw_circle(base, JOY_RADIUS, Color(1, 1, 1, 0.10))
    _overlay.draw_circle(base + move_vector * JOY_RADIUS, 40.0, Color(1, 0.2, 0.6, 0.45))
    var r := _jump_rect()
    var c := Color(0.2, 1.0, 0.9, 0.45) if jump_held else Color(1, 1, 1, 0.15)
    _overlay.draw_circle(r.get_center(), BTN_SIZE * 0.5, c)
