extends Node3D
# Fase 1: arena basica + jogador + controles de toque + alvo de teste (sem dano ainda).

var player: CharacterBody3D
var touch: CanvasLayer
var fps_label: Label


func _ready() -> void:
    _build_environment()
    _build_arena()
    _build_player()
    _build_hud()


func _process(_delta: float) -> void:
    # Medido no aparelho onde roda. FPS de PC NAO vale como FPS de celular.
    fps_label.text = "FPS: %d" % Engine.get_frames_per_second()


func _build_environment() -> void:
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.05, 0.04, 0.08)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.55, 0.5, 0.6)
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-50.0, 30.0, 0.0)
    sun.shadow_enabled = false   # desempenho em celular modesto
    add_child(sun)


func _add_box(name_: String, pos: Vector3, size: Vector3, color: Color, rot_deg := Vector3.ZERO) -> StaticBody3D:
    var body := StaticBody3D.new()
    body.name = name_
    body.position = pos
    body.rotation_degrees = rot_deg
    var mesh := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mesh.mesh = bm
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mesh.material_override = mat
    body.add_child(mesh)
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = size
    cs.shape = bs
    body.add_child(cs)
    add_child(body)
    return body


func _build_arena() -> void:
    var concrete := Color(0.45, 0.45, 0.47)
    var dark := Color(0.2, 0.2, 0.24)
    var neon := Color(1.0, 0.15, 0.55)
    _add_box("Floor", Vector3(0, -0.5, 0), Vector3(60, 1, 60), dark)
    _add_box("WallN", Vector3(0, 3, -30.5), Vector3(61, 6, 1), concrete)
    _add_box("WallS", Vector3(0, 3, 30.5), Vector3(61, 6, 1), concrete)
    _add_box("WallE", Vector3(30.5, 3, 0), Vector3(1, 6, 61), concrete)
    _add_box("WallW", Vector3(-30.5, 3, 0), Vector3(1, 6, 61), concrete)
    # Cobertura e rotas alternativas
    _add_box("Cover1", Vector3(-8, 1, 5), Vector3(4, 2, 1.5), concrete)
    _add_box("Cover2", Vector3(8, 1, 5), Vector3(4, 2, 1.5), concrete)
    _add_box("Pillar1", Vector3(0, 3, -5), Vector3(2, 6, 2), neon)
    _add_box("Platform", Vector3(-18, 1.5, -15), Vector3(10, 3, 10), concrete)
    _add_box("Ramp", Vector3(-10, 1.0, -15), Vector3(8, 0.4, 6), dark, Vector3(0, 0, 20))
    _add_box("Crate1", Vector3(15, 0.75, -8), Vector3(1.5, 1.5, 1.5), neon)
    _add_box("Crate2", Vector3(17, 0.75, -9), Vector3(1.5, 1.5, 1.5), neon)
    # Alvo de teste (ainda sem vida/dano: Fase 2)
    _add_box("TargetDummy", Vector3(0, 1, -20), Vector3(1.2, 2.0, 0.6), Color(1.0, 0.8, 0.1))


func _build_player() -> void:
    player = CharacterBody3D.new()
    player.set_script(load("res://scripts/player.gd"))
    player.name = "Player"
    player.position = Vector3(0, 0.1, 20)
    touch = CanvasLayer.new()
    touch.set_script(load("res://scripts/touch_controls.gd"))
    touch.name = "TouchControls"
    player.touch = touch
    add_child(player)
    add_child(touch)


func _build_hud() -> void:
    var layer := CanvasLayer.new()
    fps_label = Label.new()
    fps_label.position = Vector2(16, 12)
    fps_label.add_theme_font_size_override("font_size", 28)
    layer.add_child(fps_label)
    add_child(layer)
