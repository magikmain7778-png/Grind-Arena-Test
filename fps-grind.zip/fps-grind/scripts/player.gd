extends CharacterBody3D
# Jogador em primeira pessoa. Corpo e camera sao criados por codigo para o
# prototipo nao depender de cenas montadas a mao.

const SPEED := 7.0
const JUMP_VELOCITY := 7.0
const GRAVITY := 20.0
const LOOK_SENS := 0.004

var touch = null   # preenchido pelo main.gd (TouchControls)
var head: Node3D
var camera: Camera3D
var _pitch := 0.0


func _ready() -> void:
    var shape := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.4
    cap.height = 1.8
    shape.shape = cap
    shape.position.y = 0.9
    add_child(shape)
    head = Node3D.new()
    head.position.y = 1.6
    add_child(head)
    camera = Camera3D.new()
    camera.fov = 80.0
    head.add_child(camera)
    camera.current = true


func _physics_process(delta: float) -> void:
    var move := Vector2.ZERO
    var want_jump := false
    if touch != null:
        var look: Vector2 = touch.consume_look()
        rotate_y(-look.x * LOOK_SENS)
        _pitch = clampf(_pitch - look.y * LOOK_SENS, -1.4, 1.4)
        head.rotation.x = _pitch
        move = touch.move_vector
        want_jump = touch.jump_held
    # Teclado so para testar no PC
    if Input.is_key_pressed(KEY_W): move.y -= 1.0
    if Input.is_key_pressed(KEY_S): move.y += 1.0
    if Input.is_key_pressed(KEY_A): move.x -= 1.0
    if Input.is_key_pressed(KEY_D): move.x += 1.0
    if Input.is_key_pressed(KEY_SPACE): want_jump = true

    var dir := transform.basis * Vector3(move.x, 0.0, move.y)
    if dir.length() > 1.0:
        dir = dir.normalized()
    velocity.x = dir.x * SPEED
    velocity.z = dir.z * SPEED
    if not is_on_floor():
        velocity.y -= GRAVITY * delta
    elif want_jump:
        velocity.y = JUMP_VELOCITY
    move_and_slide()
