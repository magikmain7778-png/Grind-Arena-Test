# Problemas conhecidos / riscos
- Código nunca executado no Godot: pode haver erros de sintaxe/API que só aparecem ao abrir.
- A rampa (rotação no eixo Z) pode ser íngreme demais para subir; ajustar após teste real.
- Alvo ainda não recebe dano (Fase 2).
- Sem ícone, sem keystore, sem preset de exportação Android.
- Sem internet no terminal: não consigo baixar Godot nem o SDK aqui.
