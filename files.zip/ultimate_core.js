/*
 * ultimate_core.js
 * Núcleo de estados globais + Ultimates + combos.
 * Sem dependências. Roda no navegador (GDevelop) e no Node (testes).
 *
 * Ideia central:
 *   - Só o HOST decide. Clientes pedem ("request") e recebem SNAPSHOTS completos.
 *   - Snapshot completo (não delta) => tolera perda/atraso/reordenação de mensagens.
 *   - O relógio usado é só o do host => nenhum dispositivo inventa resultado.
 *
 * SUGESTÃO NOVA (precisa da sua aprovação): "canais".
 *   Cada estado ocupa 1 ou mais canais (ex.: tempo, arena, combate).
 *   Um estado persiste num canal até outro estado ocupar o MESMO canal.
 *   Estados de canais diferentes coexistem (compatíveis).
 *   Se quiser o modelo "um único estado global", use um só canal.
 */
(function (root) {
  'use strict';

  function clone(o) { return JSON.parse(JSON.stringify(o)); }

  // ---------------------------------------------------------------
  // REGISTRO (dados: canais, estados, ultimates, combos)
  // ---------------------------------------------------------------
  function createRegistry() {
    var channels = {};   // nome -> { name, defaultState }
    var states = {};     // id -> { id, channels[], rules{}, music{} }
    var ultimates = {};  // id -> { id, state }
    var combos = [];     // { id, needs[2], state }
    var validated = false;

    var reg = {
      defineChannel: function (name, defaultStateId, defaultRules) {
        if (channels[name]) throw new Error('Canal já existe: ' + name);
        channels[name] = { name: name, defaultState: defaultStateId };
        reg.defineState(defaultStateId, { channels: [name], rules: defaultRules || {} });
        validated = false;
        return reg;
      },
      defineState: function (id, def) {
        if (states[id]) throw new Error('Estado já existe: ' + id);
        if (!def.channels || !def.channels.length) throw new Error('Estado sem canais: ' + id);
        def.channels.forEach(function (c) {
          if (!channels[c]) throw new Error('Canal desconhecido "' + c + '" no estado ' + id);
        });
        states[id] = {
          id: id,
          channels: def.channels.slice(),
          rules: clone(def.rules || {}),
          music: clone(def.music || {})   // só um "gancho" para a música futura
        };
        validated = false;
        return reg;
      },
      defineUltimate: function (id, def) {
        if (ultimates[id]) throw new Error('Ultimate já existe: ' + id);
        ultimates[id] = { id: id, state: def.state };
        validated = false;
        return reg;
      },
      defineCombo: function (id, def) {
        if (!def.needs || def.needs.length !== 2) throw new Error('Combo precisa de exatamente 2 ultimates: ' + id);
        combos.push({ id: id, needs: def.needs.slice(), state: def.state });
        validated = false;
        return reg;
      },

      // Dois estados são compatíveis se NÃO disputam nenhum canal.
      compatible: function (a, b) {
        var A = states[a], B = states[b];
        if (!A || !B) throw new Error('Estado desconhecido');
        return !A.channels.some(function (c) { return B.channels.indexOf(c) !== -1; });
      },

      validate: function () {
        if (validated) return reg;
        Object.keys(ultimates).forEach(function (u) {
          if (!states[ultimates[u].state]) throw new Error('Ultimate ' + u + ' aponta para estado inexistente');
        });
        combos.forEach(function (c) {
          c.needs.forEach(function (u) {
            if (!ultimates[u]) throw new Error('Combo ' + c.id + ' usa ultimate inexistente: ' + u);
          });
          if (!states[c.state]) throw new Error('Combo ' + c.id + ' aponta para estado inexistente');
        });
        // Conflito de regras: dois estados de canais disjuntos (podem estar ativos
        // ao mesmo tempo) não podem definir a mesma chave de regra.
        var ids = Object.keys(states);
        for (var i = 0; i < ids.length; i++) {
          for (var j = i + 1; j < ids.length; j++) {
            var A = states[ids[i]], B = states[ids[j]];
            if (!reg.compatible(A.id, B.id)) continue;
            Object.keys(A.rules).forEach(function (k) {
              if (Object.prototype.hasOwnProperty.call(B.rules, k)) {
                throw new Error('Conflito: regra "' + k + '" definida por ' + A.id + ' e ' + B.id +
                  ' (podem estar ativos juntos). Mova para o mesmo canal ou renomeie.');
              }
            });
          }
        }
        validated = true;
        return reg;
      },

      // acesso interno (somente leitura)
      _channels: channels, _states: states, _ultimates: ultimates, _combos: combos
    };
    return reg;
  }

  // ---------------------------------------------------------------
  // HOST (autoridade)
  // ---------------------------------------------------------------
  function createHost(registry, opts) {
    registry.validate();
    opts = opts || {};
    var windowMs = opts.comboWindowMs == null ? 500 : opts.comboWindowMs;
    var S = registry._states, CH = registry._channels, U = registry._ultimates, COMBOS = registry._combos;
    var chNames = Object.keys(CH);

    var seq = 0;
    var active = {};          // canal -> id do estado
    chNames.forEach(function (c) { active[c] = CH[c].defaultState; });
    var lastCause = { type: 'init' };
    var lastActivated = null;
    var pending = [];         // { player, ultimate, t }

    function effectiveRules() {
      var rules = {};
      chNames.forEach(function (c) { Object.assign(rules, S[CH[c].defaultState].rules); });
      var seen = {};
      chNames.forEach(function (c) {
        var id = active[c];
        if (seen[id]) return;
        seen[id] = true;
        Object.assign(rules, S[id].rules);
      });
      return rules;
    }

    function snapshot() {
      return {
        seq: seq,
        ch: clone(active),
        rules: effectiveRules(),
        activated: lastActivated,
        music: lastActivated ? clone(S[lastActivated].music) : {},
        cause: clone(lastCause)
      };
    }

    // Aplica um estado: substitui o que ocupa os canais dele.
    function commit(stateId, cause) {
      var st = S[stateId];
      var touching = {};
      st.channels.forEach(function (c) { touching[c] = true; });
      // Se um estado multi-canal perde UM canal, ele inteiro termina:
      // os outros canais dele voltam ao padrão.
      st.channels.forEach(function (c) {
        var occupant = S[active[c]];
        if (occupant.id !== stateId && occupant.channels.length > 1) {
          occupant.channels.forEach(function (oc) {
            if (!touching[oc]) active[oc] = CH[oc].defaultState;
          });
        }
      });
      st.channels.forEach(function (c) { active[c] = stateId; });
      seq += 1;
      lastCause = cause;
      lastActivated = stateId;
      return snapshot();
    }

    function findCombo(a, b) {
      for (var i = 0; i < COMBOS.length; i++) {
        var n = COMBOS[i].needs;
        if ((n[0] === a && n[1] === b) || (n[0] === b && n[1] === a)) return COMBOS[i];
      }
      return null;
    }

    // Confirma ativações solo cujo tempo de espera acabou.
    function tick(now) {
      var out = [];
      while (pending.length && now - pending[0].t >= windowMs) {
        var p = pending.shift();
        out.push(commit(U[p.ultimate].state, { type: 'ultimate', ultimate: p.ultimate, player: p.player }));
      }
      return out;
    }

    // Um jogador pede para ativar um Ultimate. Retorna lista de snapshots novos.
    function request(now, player, ultimate) {
      var out = tick(now);
      if (!U[ultimate]) return out;                       // entrada inválida: ignora
      for (var k = 0; k < pending.length; k++) {
        if (pending[k].player === player) return out;     // já tem um pendente: ignora
      }
      for (var i = 0; i < pending.length; i++) {
        var p = pending[i];
        if (p.player === player) continue;
        var combo = findCombo(p.ultimate, ultimate);
        if (combo) {
          pending.splice(i, 1);
          out.push(commit(combo.state, {
            type: 'combo', combo: combo.id,
            players: [p.player, player], ultimates: [p.ultimate, ultimate]
          }));
          return out;
        }
      }
      pending.push({ player: player, ultimate: ultimate, t: now });
      return out;
    }

    return {
      request: request,
      tick: tick,
      snapshot: snapshot,
      snapshotJSON: function () { return JSON.stringify(snapshot()); },
      pendingCount: function () { return pending.length; }
    };
  }

  // ---------------------------------------------------------------
  // CLIENTE (só recebe e aplica snapshots do host)
  // ---------------------------------------------------------------
  function createClient() {
    var cur = null;
    var listeners = [];
    return {
      // cb({ initial, from, to, changedChannels, cause, music })
      onTransition: function (cb) { listeners.push(cb); },
      apply: function (snap) {
        if (typeof snap === 'string') snap = JSON.parse(snap);
        if (cur && snap.seq <= cur.seq) return false;     // velho ou duplicado
        var prev = cur;
        cur = snap;
        var changed = [];
        Object.keys(snap.ch).forEach(function (c) {
          if (!prev || prev.ch[c] !== snap.ch[c]) changed.push(c);
        });
        var info = {
          initial: !prev,            // quem entra no meio da partida: pular direto, sem "efeito de transição"
          from: prev, to: snap,
          changedChannels: changed,
          cause: snap.cause, music: snap.music
        };
        listeners.forEach(function (cb) { cb(info); });
        return true;
      },
      state: function () { return cur; },
      rule: function (key, fallback) {
        return cur && Object.prototype.hasOwnProperty.call(cur.rules, key) ? cur.rules[key] : fallback;
      },
      seq: function () { return cur ? cur.seq : -1; }
    };
  }

  var API = { createRegistry: createRegistry, createHost: createHost, createClient: createClient };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  root.UltCore = API;
})(typeof globalThis !== 'undefined' ? globalThis : this);
