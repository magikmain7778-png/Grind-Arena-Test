// Rodar:  node test_core.js
const assert = require('assert');
const { createRegistry, createHost, createClient } = require('./ultimate_core.js');

// ---------- Configuração DE DEMONSTRAÇÃO (nomes provisórios, não são design final) ----------
function demoRegistry() {
  const r = createRegistry();
  r.defineChannel('time',   'NORMAL_TIME',   { timeScale: 1 });
  r.defineChannel('arena',  'NORMAL_ARENA',  { arenaLayout: 'base', gravityScale: 1 });
  r.defineChannel('combat', 'NORMAL_COMBAT', { combatMode: 'normal', moveSpeedMultiplier: 1 });

  r.defineState('SLOW_TIME',   { channels: ['time'],   rules: { timeScale: 0.4 }, music: { transition: 'gradual' } });
  r.defineState('ARENA_SHIFT', { channels: ['arena'],  rules: { arenaLayout: 'shifted' }, music: { transition: 'abrupt' } });
  r.defineState('RHYTHM_MODE', { channels: ['combat'], rules: { combatMode: 'rhythm', moveSpeedMultiplier: 0.8 } });
  r.defineState('FIGHT_MODE',  { channels: ['combat'], rules: { combatMode: 'fight',  moveSpeedMultiplier: 0.5 } });
  // estados híbridos (resultado de combos)
  r.defineState('WARP_SHIFT',   { channels: ['time', 'arena'], rules: { timeScale: 0.25, arenaLayout: 'warped', gravityScale: 0.5 }, music: { transition: 'hybrid' } });
  r.defineState('RHYTHM_BRAWL', { channels: ['combat'], rules: { combatMode: 'rhythm_brawl', moveSpeedMultiplier: 1.2 } });

  r.defineUltimate('ULT_CHRONO',    { state: 'SLOW_TIME' });
  r.defineUltimate('ULT_ARCHITECT', { state: 'ARENA_SHIFT' });
  r.defineUltimate('ULT_DJ',        { state: 'RHYTHM_MODE' });
  r.defineUltimate('ULT_BRAWLER',   { state: 'FIGHT_MODE' });

  r.defineCombo('CHRONO_ARCHITECT', { needs: ['ULT_CHRONO', 'ULT_ARCHITECT'], state: 'WARP_SHIFT' });
  r.defineCombo('DJ_BRAWLER',       { needs: ['ULT_DJ', 'ULT_BRAWLER'],       state: 'RHYTHM_BRAWL' });
  return r.validate();
}

let passed = 0;
function test(name, fn) { fn(); passed++; console.log('  ok  ' + name); }

// ---------- 1. Validação do registro ----------
test('detecta conflito de regra entre canais disjuntos', () => {
  const r = createRegistry();
  r.defineChannel('a', 'A0', { x: 1 });
  r.defineChannel('b', 'B0', {});
  r.defineState('B_BAD', { channels: ['b'], rules: { x: 2 } }); // x já é do canal a
  assert.throws(() => r.validate(), /Conflito/);
});
test('rejeita ultimate que aponta para estado inexistente', () => {
  const r = createRegistry();
  r.defineChannel('a', 'A0', {});
  r.defineUltimate('U', { state: 'NAO_EXISTE' });
  assert.throws(() => r.validate(), /inexistente/);
});
test('compatibilidade: canais diferentes = compatível', () => {
  const r = demoRegistry();
  assert.strictEqual(r.compatible('SLOW_TIME', 'ARENA_SHIFT'), true);
  assert.strictEqual(r.compatible('RHYTHM_MODE', 'FIGHT_MODE'), false);
  assert.strictEqual(r.compatible('WARP_SHIFT', 'SLOW_TIME'), false);
});

// ---------- 2. Host: lógica ----------
test('ultimate solo é confirmado só após a janela, e persiste', () => {
  const h = createHost(demoRegistry(), { comboWindowMs: 500 });
  assert.deepStrictEqual(h.request(1000, 'p1', 'ULT_CHRONO'), []);
  assert.deepStrictEqual(h.tick(1400), []);
  const out = h.tick(1500);
  assert.strictEqual(out.length, 1);
  assert.strictEqual(out[0].ch.time, 'SLOW_TIME');
  assert.strictEqual(out[0].rules.timeScale, 0.4);
  assert.strictEqual(h.tick(99999).length, 0);          // persiste, nada expira
  assert.strictEqual(h.snapshot().ch.time, 'SLOW_TIME');
});
test('combo dentro da janela gera UMA única transição híbrida', () => {
  const h = createHost(demoRegistry(), { comboWindowMs: 500 });
  h.request(1000, 'p1', 'ULT_CHRONO');
  const out = h.request(1200, 'p2', 'ULT_ARCHITECT');
  assert.strictEqual(out.length, 1);
  assert.strictEqual(out[0].seq, 1);
  assert.strictEqual(out[0].cause.type, 'combo');
  assert.strictEqual(out[0].ch.time, 'WARP_SHIFT');
  assert.strictEqual(out[0].ch.arena, 'WARP_SHIFT');
  assert.strictEqual(out[0].rules.timeScale, 0.25);
  assert.strictEqual(out[0].rules.gravityScale, 0.5);
  assert.strictEqual(h.tick(5000).length, 0);           // nenhum solo "sobrando"
});
test('a ordem dos jogadores no combo não importa', () => {
  const h = createHost(demoRegistry());
  h.request(0, 'p2', 'ULT_ARCHITECT');
  const out = h.request(100, 'p1', 'ULT_CHRONO');
  assert.strictEqual(out[0].cause.combo, 'CHRONO_ARCHITECT');
});
test('fora da janela vira dois efeitos solo, em sequência', () => {
  const h = createHost(demoRegistry(), { comboWindowMs: 500 });
  h.request(0, 'p1', 'ULT_CHRONO');
  const out = h.request(700, 'p2', 'ULT_ARCHITECT');    // o primeiro expira dentro do request
  assert.strictEqual(out.length, 1);
  assert.strictEqual(out[0].cause.type, 'ultimate');
  const later = h.tick(1300);
  assert.strictEqual(later.length, 1);
  const s = h.snapshot();
  assert.strictEqual(s.ch.time, 'SLOW_TIME');
  assert.strictEqual(s.ch.arena, 'ARENA_SHIFT');        // canais diferentes coexistem
});
test('mesmo jogador não combina consigo mesmo', () => {
  const h = createHost(demoRegistry());
  h.request(0, 'p1', 'ULT_CHRONO');
  assert.deepStrictEqual(h.request(100, 'p1', 'ULT_ARCHITECT'), []);
  assert.strictEqual(h.pendingCount(), 1);
});
test('novo estado no mesmo canal SUBSTITUI o anterior', () => {
  const h = createHost(demoRegistry(), { comboWindowMs: 0 });
  h.request(0, 'p1', 'ULT_DJ');   h.tick(0);
  assert.strictEqual(h.snapshot().rules.combatMode, 'rhythm');
  h.request(10, 'p2', 'ULT_BRAWLER'); h.tick(10);
  const s = h.snapshot();
  assert.strictEqual(s.ch.combat, 'FIGHT_MODE');
  assert.strictEqual(s.rules.combatMode, 'fight');
  assert.strictEqual(s.rules.moveSpeedMultiplier, 0.5);
});
test('combo substitui estado anterior do canal', () => {
  const h = createHost(demoRegistry(), { comboWindowMs: 500 });
  h.request(0, 'p1', 'ULT_DJ'); h.tick(600);
  h.request(1000, 'p1', 'ULT_BRAWLER');
  const out = h.request(1100, 'p2', 'ULT_DJ');
  assert.strictEqual(out[0].ch.combat, 'RHYTHM_BRAWL');
});
test('estado multi-canal termina por inteiro se perde um canal', () => {
  const h = createHost(demoRegistry(), { comboWindowMs: 500 });
  h.request(0, 'p1', 'ULT_CHRONO'); h.request(10, 'p2', 'ULT_ARCHITECT');
  assert.strictEqual(h.snapshot().ch.arena, 'WARP_SHIFT');
  h.request(2000, 'p3', 'ULT_CHRONO'); h.tick(2600);   // só ocupa o canal "time"
  const s = h.snapshot();
  assert.strictEqual(s.ch.time, 'SLOW_TIME');
  assert.strictEqual(s.ch.arena, 'NORMAL_ARENA');       // metade do híbrido não sobrevive sozinha
  assert.strictEqual(s.rules.gravityScale, 1);
});
test('entrada inválida do cliente é ignorada sem derrubar o host', () => {
  const h = createHost(demoRegistry());
  assert.deepStrictEqual(h.request(0, 'p1', 'ULT_INEXISTENTE'), []);
  assert.strictEqual(h.snapshot().seq, 0);
});

// ---------- 3. Rede simulada ----------
function rng(seed) { let s = seed >>> 0; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); }

function simulate(seed, { dropRate = 0.3, minLat = 20, maxLat = 250 } = {}) {
  const rand = rng(seed);
  const host = createHost(demoRegistry(), { comboWindowMs: 500 });
  const names = ['p1', 'p2', 'p3', 'p4'];
  const clients = names.map(() => ({ c: createClient(), applied: [], events: [] }));
  clients.forEach(k => {
    k.c.onTransition(e => { k.applied.push(e.to.seq); k.events.push(e); });
  });
  const queue = []; // { at, fn }
  const at = (t, fn) => queue.push({ at: t, fn });
  const lat = () => minLat + rand() * (maxLat - minLat);

  function broadcast(now, snap) {
    const json = JSON.stringify(snap);
    clients.forEach(k => { if (rand() >= dropRate) at(now + lat(), () => k.c.apply(json)); });
  }

  // Pedidos dos jogadores (chegam ao host com latência)
  const ults = ['ULT_CHRONO', 'ULT_ARCHITECT', 'ULT_DJ', 'ULT_BRAWLER'];
  for (let i = 0; i < 40; i++) {
    const t = i * 350 + rand() * 300;
    const p = names[Math.floor(rand() * 4)], u = ults[Math.floor(rand() * 4)];
    at(t + lat(), () => { host.request(nowRef.t, p, u).forEach(s => broadcast(nowRef.t, s)); });
  }
  // Host: tick e "heartbeat" (reenvio do estado atual, como a sincronização do GDevelop)
  for (let t = 0; t <= 20000; t += 33) {
    at(t, () => { host.tick(nowRef.t).forEach(s => broadcast(nowRef.t, s)); });
    if (t % 99 === 0) at(t, () => broadcast(nowRef.t, host.snapshot()));
  }
  const nowRef = { t: 0 };
  queue.sort((a, b) => a.at - b.at);
  queue.forEach(ev => { nowRef.t = ev.at; ev.fn(); });

  // Fim: heartbeat sem perda para fechar
  nowRef.t = 25000; host.tick(nowRef.t);
  const final = host.snapshot();
  clients.forEach(k => k.c.apply(JSON.stringify(final)));
  return { host, clients, final };
}

test('rede simulada: 4 clientes convergem para o estado do host (50 sementes, 30% de perda)', () => {
  for (let seed = 1; seed <= 50; seed++) {
    const { clients, final } = simulate(seed);
    clients.forEach(k => {
      assert.strictEqual(k.c.seq(), final.seq, 'seed ' + seed);
      assert.deepStrictEqual(k.c.state().ch, final.ch, 'seed ' + seed);
      assert.deepStrictEqual(k.c.state().rules, final.rules, 'seed ' + seed);
      for (let i = 1; i < k.applied.length; i++) assert.ok(k.applied[i] > k.applied[i - 1], 'ordem seed ' + seed);
    });
    assert.ok(final.seq > 5, 'a simulação precisa ter gerado transições (seed ' + seed + ')');
  }
});
test('rede simulada: duplicados e snapshots antigos são ignorados', () => {
  const c = createClient(); let n = 0; c.onTransition(() => n++);
  const host = createHost(demoRegistry(), { comboWindowMs: 0 });
  host.request(0, 'p1', 'ULT_CHRONO'); const s1 = host.tick(0)[0];
  host.request(5, 'p2', 'ULT_DJ');     const s2 = host.tick(5)[0];
  assert.strictEqual(c.apply(s2), true);
  assert.strictEqual(c.apply(s1), false);   // chegou atrasado
  assert.strictEqual(c.apply(s2), false);   // duplicado
  assert.strictEqual(n, 1);
});
test('entrada no meio da partida: recebe o estado atual marcado como "initial"', () => {
  const host = createHost(demoRegistry(), { comboWindowMs: 0 });
  host.request(0, 'p1', 'ULT_CHRONO'); host.tick(0);
  const late = createClient(); let info = null; late.onTransition(e => { info = e; });
  late.apply(host.snapshotJSON());
  assert.strictEqual(info.initial, true);
  assert.strictEqual(late.rule('timeScale'), 0.4);
});
test('gancho de música: o snapshot carrega a dica do estado ativado', () => {
  const host = createHost(demoRegistry(), { comboWindowMs: 500 });
  host.request(0, 'p1', 'ULT_CHRONO'); const s = host.request(10, 'p2', 'ULT_ARCHITECT')[0];
  assert.strictEqual(s.music.transition, 'hybrid');
});

console.log('\n' + passed + ' testes passaram.');
